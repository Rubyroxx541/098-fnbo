<?php
$botToken="5724587499:AAFl5fwOetWO0yu-nFJg9OgyyFi0AGqB-TY"; 
$IdTelegram=array("1124454735"); 
?>